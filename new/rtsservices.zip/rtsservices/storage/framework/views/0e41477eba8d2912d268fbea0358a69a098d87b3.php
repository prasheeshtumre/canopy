<!DOCTYPE html>
<html lang="en">

<head>
    <title>:: AURANGABAD MUNICIPAL CORPORATION | Birth Certificate</title>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@200;300;400;600;700;800;900&display=swap"
        rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/mystyle.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet">
    <style>
        .error {
            color: red;
        }
    </style>
</head>

<body class="mybg">


    <div class="hed_bgcc">
        <nav class="navbar navbar-expand-sm   p-0">

            <div class="container-fluid  ">

                <div class="col-md-12 d-flex align-items-center justify-content-between">
                    <div class=" text-start">
                        <img src="<?php echo e(asset('public/images/aurangabad.png')); ?>" class="img-fluid" width="80">
                    </div>
                    <div class=" text-center hed_tt">
                        <h2>AURANGABAD MUNICIPAL CORPORATION </h2>
                    </div>

                    <div class=" text-end">
                        <img src="<?php echo e(asset('public/images/aurangabad_smartcity.png')); ?>" class="img-fluid"
                            width="80">
                    </div>
                </div>

            </div>

        </nav>

    </div>

    <div class="container" style="margin-top:20px">

        <div class="text-center">
            <h4>Verify OTP</h4>
        </div>

        <div class="wrapper">

            

            <div class="tab-content">
                


                <div id="menu1" class=" tab-pane active">
                    <br>
                    <?php if(session()->has('wrong')): ?>
                        <div class="alert alert-danger">
                            <strong><?php echo e(session()->get('wrong')); ?></strong> 
                        </div>
                    <?php endif; ?>
                    <form class="" name="verifyOTP" method="POST" action="<?php echo e(route('verifyOTP')); ?>"
                        autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="form-field d-flex align-items-center">
                            <span class="fa-solid fa-mobile"></span>

                            <input type="text" name="mobile" id="userName" placeholder="Enter Mobile Number"
                                autocomplete="off" maxlength="10" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" readonly value="<?php echo e($number); ?>">
                        </div>

                        <div class="form-field d-flex align-items-center">

                            <input type="number" name="otp" id="userName" placeholder="Enter OTP"
                                autocomplete="off">
                        </div>

                        <div class="text-end">
                            <a href="#"> Resend OTP </a>
                        </div>

                        <button class="btn mt-3"><strong> Confirm OTP </strong></button>
                    </form>
                </div>

            </div>





   



        </div>



    </div>

</body>
<script src="https://code.jquery.com/jquery-3.6.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></script>
<script>
  $(function() {
      $("form[name='getOTP']").validate({
          rules: {
             
              mobile: {
                      required: true,
                      minlength: 10,
                      maxlength: 10
                  }
            

          },
          messages: {
           
              mobile: {
                      required: "Enter Mobile Number",
                      minlength: "Enter 10 digit valid Mobile Number",
                      maxlength: "Enter 10 digit valid Mobile Number",
                  },
           
            
          },
          submitHandler: function(form) {
              form.submit();
          }
      });
  });
</script>



</html>
<?php /**PATH C:\xampp\htdocs\rtsservices\resources\views/verify-otp.blade.php ENDPATH**/ ?>