<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<div class="container mt-3">

    <div class="d-flex justify-content-between align-item-center mm_flx mb-3">
        <!--<p><?php echo e(session()->get('success')); ?></p>-->
        <h4>Application Form For Birth Certificate</h4>

        

    </div>

    <?php if(session()->has('success')): ?>
        <div class="col-12">
            <div class="alert alert-success">
                <strong>Success!</strong> <?php echo e(session()->get('success')); ?>

            </div>
        </div>
    <?php endif; ?>
    
        <div class="row">
            <form name="BirthForm" method="POST" action="<?php echo e(route('getApplicationData')); ?>" id="BirthForm"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="col-md-6">
                    <div class="mb-3 mt-3">
                        <label for="" class="form-label lbleng">Application ID</label>
                       
                        <input type="text" class="form-control" id="" placeholder="" name="app_id" value="<?php echo e($application_data->rtiapplrefno); ?>" required>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="mb-3 mt-5">
                        <button class="btn btn-success btn_sm" type="submit" id="submitBtn"><i
                            class="fa-solid fa-check"></i> Get </button>
                    </div>
                </div>
            </form>
         
           <?php
           $status_data = array(0=>'In Process',1=>'Completed',5=>'Rejected');
         // echo $status_data[1]; exit();
         // echo   var_dump($application_data->workFlowStatus) ; exit();
           ?>
            <div class="col-md-12">
                <table class="table table-bordered">
                    <thead>
                      <tr>
                       
                        <th scope="col">Names</th>
                        <th scope="col">Data</th>
                       
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                       
                        <td>Name of Applicant</td>
                        <td><?php echo e($application_data->name); ?></td>
                        
                      </tr>
                      <tr>
                       
                        <td> Applicant No</td>
                        <td><?php echo e($application_data->rtiapplrefno); ?></td>
                        
                      </tr>
                      <tr>
                        
                        <td>   Mobile No of applicant</td>
                        <td><?php echo e($application_data->ph_no); ?></td>
                      
                      </tr>
                      <tr>
                        
                        <td> Ward Name</td>
                        <td><?php echo e($application_data->wardName); ?></td>
                       
                      </tr>
                      <tr>
                        
                        <td> Name of Officer</td>
                        <td><?php echo e($application_data->wardOffcierName); ?></td>
                       
                      </tr>
                      <tr>
                        
                        <td> Application Status (Completed/Under Process/Rejected)</td>
                        <td><?php $che =(int)$application_data->workFlowStatus; echo  $status_data[$che]; ?></td>
                       
                      </tr>
                      <tr>
                        
                        <td>PDF file</td>
                        <td><a href="<?php echo e($application_data->pdfsavedpath); ?>" class="" ><?php echo e($application_data->pdfsavedpath); ?></a></td>
                       
                      </tr>
                    </tbody>
                  </table>
            </div>
          

        </div>



  



    </form>






</div>




<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;








</body>

</html>
<?php /**PATH C:\xampp\htdocs\rtsservices\resources\views/get_application.blade.php ENDPATH**/ ?>